# TeknikServis
Bir kullanıcının satın aldığı ürünün arızalandığını bildirmek amacıyla sisteme girerek hangi ürünün markasını ve hatasını bildirmesi için oluşturulmuş mvc projesi
